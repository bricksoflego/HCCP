﻿namespace BlueDragon.Data
{
    /// <summary>
    /// 
    /// </summary>
    enum LocationUsed
    {
        OfficeSupplies,
        Office,
        MediaCabinet,
        FamilyRoom,
        PinkRoom,
        NathanRoom,
        NathanBath,
        Garage,
        PianoStudio,
        MusicCloset,
        MasterBedroom,
        MasterBath,
        Kitchen,
        NoahRoom,
        NoahBath,
        LaundryRoom,
        Other
    }
}
