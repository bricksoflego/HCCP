﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BlueDragon.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueDragon.Services.Tests
{
    [TestClass()]
    public class HardwareServiceTests
    {
        [TestMethod()]
        public void GetHardwareTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetSelectedHardwareTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void UpsertTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void DeleteTest()
        {
            Assert.Fail();
        }
    }
}